#help#

if [ "$1" == "-help" ]; then
    echo "  USO: backup_full.sh [ORIGEN] [DESTINO]"
    echo "-------------------------------------------------"
    echo "  ARGUMENTOS:"
    echo "    ORIGEN:  Directorio a backupear"
    echo "    DESTINO: Directorio donde guardar el backup"
    echo ""
    echo "  EJEMPLO:"
    echo "    backup_full.sh /var/log /backup_dir"
    echo ""
    echo "  OPCIONES:"
    echo "    -help : muestra esta ayuda"
    echo "-----------------------------------------------"
    exit 0
fi

#valido origen y destino#

if [ $# -ne 2 ]; then
    echo "ERROR: Debe especificar origen y destino."
    exit 1
fi

ORIGEN=$1
DESTINO=$2

#validamos que el origen y el destino existan#
if [ ! -e "$ORIGEN" ]; then
    echo "ERROR: El directorio origen '$ORIGEN' no existe o no esta disponible."
    exit 1
fi

if [ ! -e "$DESTINO" ]; then
    echo "ERROR: El directorio destino '$DESTINO' no existe o no esta disponible."
    exit 1
fi


#crear archivo#

FECHA=`date +%Y%m%d` 

if [ "$ORIGEN" == "/var/log" ]; then
    NOMBRE="log"
else

	if [ "$ORIGEN" == "/www_dir" ]; then
    		NOMBRE="www_dir"
	fi
fi

ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

#ejecuto bkp#

tar -czpf "$DESTINO/$ARCHIVO" "$ORIGEN"
if [ $? -eq 0 ]; then
    echo "Backup completado exitosamente: $DESTINO/$ARCHIVO"
else
    echo "ERROR: El backup fallo."
    exit 1
fi




