FECHA=`date +%Y%m%d`
echo $FECHA
