history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /root/.ssh/authorized_keys << 'ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQDom0gO3Rr2B2IUlyp3HgGMohZzNFfXxgugYcUrpXjcCQHEJ/xZvmY05MZFF5cN3fXTDYadWNDtIC3IpCHYD9dS3RCVrjztayH5CsdE5oBImrVea85bYspZfKlNZ/328r4uQh/8+LcpqpGDvTlj2f8GnnPhABQq5lwoVZ04D9ZOsbwBQM3wVg9POMZo8WXjtPpYvVxfQb6RZNBZoY17EUF73rWlm63Qz6kI5tq6yMyZyaqZGr7G4x+yAV7N/YWxqmNz+fE4Awv3QNyH6xhKIkRTnajEW68aeQuFX+oY0KBSDhyvYeUZvki2s7jVWNXxMu07xYQv7G7VKL14N9Tl3t0i11tsalhyWxBspyzSQmjgQCrOxvCgNUbsaP5/wHATty64QQHLL+roPHxtds/nJcnwHO5fGm3E6iIG4t3ODUrWfd+FkLmlEhzk8+cm8U1G9x58u/NXH4hI264nWR0k6lrnAfSWzlP38B39uFgrjLqzljA8HmAUOBxYLIHmU6nnfTk= sonda@ttys9-HP-ENVY-Notebook'

cat
cat /etc/ssh/sshd_config

ssh 

cat /etc/ssh/sshd_config
cat > /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
scp -i "C:\Users\demy1\Desktop\Facu\TP Linux\index.php" root@192.168.0.102:/root/
scp -i C:\Users\demy1\Desktop\Facu\TP Linux\index.php root@192.168.0.102:/root/
apt install mariadb-server
systemctl status mariadb
exit
scp -i C:\Users\demy1\Desktop\Facu\TPLinux\index.php root@192.168.0.102:/root/
scp -i "C:\Users\demy1\Desktop\Facu\TPLinux\index.php" root@192.168.0.102:/root/
hostnamectl set-hostname TPServer
hostnamectl
apt update
apt update && apt updgrade -y
apt upgrade
ip a
ip route
ping -c 8.8.8.8
ping -c 3 8.8.8.8
ping -c 3 google.com
apt update && apt updgrade -y
at /etc/apt/sources.list
cat /etc/apt/sources.list
nano /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt update && apt updgrade -y
apt upgrade
apt install openssh-server
ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
chmod 700 /root/.ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl enable ssh
systemctl status ssh
ls -la /root/.ssh
ping google.com
systemctl status ssh
apt install apache 2 php libapache2-mod-php
apt-get update
apt install apache 2 php libapache2-mod-php
apt install apache2 php libapache2-mod-php
php -v
systemctl status apache2
cd /var/www/html
ls -l
ls 
ls -la /var/www/html
fin / -name "logo.png" 2>/dev/null
find / -name "logo.png" 2>/dev/null
cat /var/www/html/index.php
ls
find /name "index.php" 2>/dev/null
cd ..
cd ..
cd..
cd..
cd ..
cd ..
ls
cd home
ls
cd compartido
ls
cd ..
cd lost+found
ls
cd ..
cd ..
ls
find / "index.php"
find / -name "index.php"
find / -name "*.php"
ls
cd home
ls
ls -l
cd compartido
ls
ls -l
cd dir1
ls
cd ..
ls
cd ..
ls
cd lost+found
ls -l
ls
cd ..
cd..
cd ..
ls
cd media
ls
cd ..
ls -l
cd mnt
ls
cd ..
cd opt
ls
cd ..
cd proc
ls
cd ..
cd root
ls
cd ..
ls -l
cd run
ls
cd apache2
ls
cd ..
cd ..
cd sbin
ls
ls -p
ls -s
ls -h
cd ..
ls
cd srv
ls
cd ..
cd sys
ls
cd ..
ls tmp
cd tmp
ls
cd ..
cd usr
ls
cd ..
cd var 
ls
cd www
ls
cd html
ls
cd ..
cd ..
cd ..
cd home
ls
ls
cd compartido
ls
cd ..
ls
cd compartido
ls
cd ..
cd ..
ls
ls -l
find / -name "*ateria"
ipa
ip a
systemctl status ssh
grep PermitRootLogin /etc/ssh/sshd_config
cat /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
ls -la /root/.ssh/
cat /root/.ssh/id_rsa
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
vi /etc/ssh/sshd_confi
vi /etc/ssh/sshd_config
systemctl status ssh
systemctl restart ssh
systemctl status ssh
apt install virtualbox-guest-utils -y
apt install virtualbox-guest-utils
ip a
cd /root
ls
tar -x Material_Adicional_TPVMCA.tar.gz
tar -x Material_Adicional_TPVMCA.tar.gz
tar -fx Material_Adicional_TPVMCA.tar.gz
tar --help
tar -xzvf Material_Adicional_TPVMCA.tar.gz
ls
cd Material_Adicional_TPVMCA
cd
cd Material_Adicional_TPVMCA
ls
cp logo.png /root/
cd ..}
cd ..
ls
cd Material_Adicional_TPVMCA
ls
cp db.sql /root/
cd ..
ls
vi /etc/network/interfaces
vi /etc/network/interfaces
systemctl restart networking
ip a
vi /etc/network/interfaces
systemctl restart networking
systemctl poweroff
systemctl start mariadb
mysql_secure_installation
mysql -u root -p </root/db.sql
mysql -u root -p
ip a
vi /etc/network/interfaces
ip a
vi /etc/network/interfaces
vi /etc/network/interfaces
vi /etc/network/interfaces
lsblk
fdisk /dev/sdc
lsblk
mkfs -t ext4 /dev/sdc1 , /dev/sdc2
mkfs -t ext4 /dev/sdc1 ; /dev/sdc2
mkfs -t ext4 /dev/sdc2
lsblk
df -h
mkdir www_dir
rmdir www_dir
/# mkdir www_dir
mkdir www_dir
mkdir backup_dir
mount /dev/sdc1 /www_dir
ls
mount /dev/sdc1 /home/www_dir
mv /root/www_dir /www_dir
mv /root/backup_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
vi /etc/fstab
ls
cp /root/index.php /www_dir
cp /root/logo.png /www_dir
cd /www_dir
ls
cd /root
ls /opt
cd /opt
ls
cd /root
cd /proc
ls
cat partitions
cd /root
cd /
ls
cd opt
ls
cd ..
cp /proc/partitions /opt/particion
cd /opt
ls
cat particion
cd ..
cd root
cd /etc/apache2
ls
vi etc/apache2/sites-available
vi etc/apache2/sites-available/000-default.conf
cd sites-available
ls
cat 000-default.conf
vi 000-default.conf
cd .
cd ..
ls
vi apache2.conf
systemctl restart apache2
curl http://localhost/index.php
cd ..
cd /root
curl http://localhost/index.php
which curl
exit
systemctl shutdown
shutdown
vim script.sh
ls
./script.sh
bash script.sh
chmod 755 script.sh
script.sh
./script.sh
vim script.sh
./script.sh
vim script.sh
./script.sh hola
vim script.sh
./script.sh hola manola
vim script.sh
vim script.sh
./script.sh hola manola
$?
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
vim script.sh
./script.sh hola manola
cron
vim /etc/cron
vim /etc/crontab
systemctl status apache2
vi index.php
vi index.php
whereis date
date 
ls
cd ..
cd ..
cd ..
ls
shutdown
ls
rm script.sh
ls
vim backup_full.sh
vim test.sh
./test.sh
bash test.sh
vim test.sh
vim backup_full.sh
ls /opt/scripts
cd /opt
ls
ls -l
mkdir scripts
ls
cd ..
mv backup_full.sh / /opt/scripts
mv backup_full.sh /root /opt/scripts
ls
cd root
whereis backup_full.sh
ls -l
find / -name "backup_full.sh" 2>/dev/null
cd /opt/scripts
ls
cd root
cd ..
mv /root /
ls
cd ..
cd ..
cd ..
ls -ld /root
ls -la /opt/scripts/root
cd /opt/scripts
ls
cd root
ls
ls -l
ls -la
ls -ld /root
mv /opt/scripts/root /root
ls -ld /root
ls -lda /root
cd ..
ls
cd /opt/scripts
ls
mv /root/backup_full.sh /opt/scripts/
ls -ld opt/scripts/
ls -ld opt/scripts
ls -ld /opt/scripts
cd /opt/scripts/
ls
chmod 755 /opt/scripts/backup_full.sh
backup_full.sh /var/log /backup_dir
./backup_full.sh /var/log /backup_dir
cd /backup_dir
ls
./backup_full.sh /www_dir /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls
cd ..
